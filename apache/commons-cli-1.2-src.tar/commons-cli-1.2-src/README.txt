Apache Commons CLI
===================

Welcome to the CLI 1.x component of the Apache Commons project.

The information in this file is relevant if you have
downloaded a CLI source distribution.

CLI is built with Maven 2, which can be found here:

  http://maven.apache.org

and to build and test the system use:

  mvn clean package

The system will build and test itself.

For complete documentation and to create a local copy of the
CLI project website, type:

  mvn site

Good luck!

- The Apache Commons Team
